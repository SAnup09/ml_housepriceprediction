# ML_Project-HosePricePrediction
The objective of this project was to develop a machine learning model that could accurately predict house prices in Bangalore, India. The project utilized the Bangalore house price dataset obtained from Kaggle, which contained relevant information about various houses in the area.
